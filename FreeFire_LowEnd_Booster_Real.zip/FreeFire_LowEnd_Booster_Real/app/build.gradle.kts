plugins { id("com.android.application") }

android { namespace="com.yarra.ffbooster"; compileSdk=35
    defaultConfig { applicationId="com.yarra.ffbooster"; minSdk=23; targetSdk=35; versionCode=1; versionName="1.0" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.16.0")
    implementation("com.google.android.material:material:1.13.0")
    implementation("dev.rikka.shizuku:api:13.6.0")
    implementation("dev.rikka.shizuku:provider:13.6.0")
}
